# Gid koneksyon Appwrite

1. Louvri Appwrite Console epi antre nan pwojè ZENVORA HT 21.
2. Nan pwojè a, ajoute yon platfòm Web.
3. Mete hostname sit la (pou tès lokal, `localhost`; pou sit piblik, hostname sit la egzak).
4. Kopi Project ID ak API Endpoint.
5. Fè yon kopi `appwrite-config.example.js` epi rele kopi a `appwrite-config.js`.
6. Mete endpoint ak Project ID sèlman. Pa mete API key oswa sekrè nan navigatè.
7. Ajoute script `appwrite-config.js` anvan `src/app.js` nan `index.html` lè w pare pou koneksyon.

Appwrite ka gen limit plan oswa pwojè; pa kreye plizyè pwojè san verifye limit òganizasyon an.
