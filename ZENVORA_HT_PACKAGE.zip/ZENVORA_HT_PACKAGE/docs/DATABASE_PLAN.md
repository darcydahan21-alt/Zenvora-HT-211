# Plan baz done Appwrite

Kreye koleksyon sa yo sèlman apre ou fin konprann otorizasyon yo:

- `profiles`: userId, displayName, inviteCode, createdAt
- `learning_progress`: userId, dayKey, missionId, answerStatus, points
- `mission_catalog`: dayKey, missionId, title, question, answerKey (answerKey pa dwe janm piblik)
- `admin_audit`: adminId, action, targetUserId, createdAt

Sekirite:
- Pa janm mete answerKey nan dokiman kliyan an.
- Itilizatè pa dwe kapab modifye pwòp balans/pwen pa yo dirèkteman.
- Aksyon administratè yo dwe fèt atravè fonksyon sèvè ki verifye wòl admin lan.
- Pa janm mete kle API prive nan HTML oswa JavaScript navigatè.
- Mete règleman aksè minimòm nesesè sou chak koleksyon.

Peman, depo, retrè, VIP peye ak lajan referans pa enkli nan baz pwototip sa a.
