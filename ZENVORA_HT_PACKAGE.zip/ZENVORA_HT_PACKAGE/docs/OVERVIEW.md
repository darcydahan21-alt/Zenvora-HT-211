# ZENVORA HT — Package rekonstriksyon

Package sa a se yon baz pwototip rekonstriksyon, li pa yon kopi garanti fichye orijinal ou te genyen an. Fichye orijinal la pa t disponib nan konvèsasyon an pou konpare konsepsyon an pixel pa pixel.

## 7 pati pwojè a
1. Kòd aplikasyon an: `index.html`, `src/app.js`, `src/style.css`
2. Koneksyon aplikasyon an: `appwrite-config.example.js`
3. Paj ak fonksyon: paj Dakèy, fòm enskripsyon/koneksyon, misyon, VIP ak seksyon sosyal
4. Konsepsyon: ble fonse, ble wayal, lò; adapte pou telefòn
5. Enfòmasyon koneksyon: `docs/APPWRITE_SETUP.md`
6. Gid baz done: `docs/DATABASE_PLAN.md`
7. Zouti pwojè a bezwen: `docs/TOOLS.md`

## Limit enpòtan
Sa a se yon pwototip devan (front-end). Li pa konekte ak Appwrite jiskaske ou konfigire pwojè a. Li pa trete peman, pa valide resi, pa peye lajan, pa gen retrè, epi pa gen rekonpans lajan otomatik. Pwen ki parèt yo se pwen aprantisaj demonstrasyon sèlman. Pa mande moun peye pou VIP oswa pwomèt yo revni sou baz pwototip sa a.

Anvan nenpòt sistèm peman oswa rekonpans lajan ta lanse, kondisyon legal, finansye, sekirite, verifikasyon laj ak sous finansman dwe evalye pa granmoun responsab ak pwofesyonèl apwopriye.
