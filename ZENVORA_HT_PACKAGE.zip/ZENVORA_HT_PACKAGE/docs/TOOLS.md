# Zouti pwojè a bezwen

- GitHub: sere kòd la epi suiv chanjman.
- Appwrite Cloud: otantifikasyon ak baz done.
- Chrome: teste sit la sou telefòn.
- Editè kòd: modifye HTML, CSS ak JavaScript.
- Hosting estatik: pibliye paj entènèt la.

GitHub Pages oswa hosting estatik pa egzekite lojik sekrè. Nenpòt verifikasyon ki mande privilèj admin dwe fèt sou sèvè/fonksyon backend.
