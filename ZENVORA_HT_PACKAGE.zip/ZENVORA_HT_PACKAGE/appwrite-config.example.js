// Rename this file to appwrite-config.js and fill in your public Appwrite values.
// Endpoint and Project ID are public client configuration.
// NEVER put an Appwrite API key, secret, or server credential in this file.
window.ZENVORA_APPWRITE = {
  endpoint: "https://<REGION>.cloud.appwrite.io/v1",
  projectId: "YOUR_PROJECT_ID"
};