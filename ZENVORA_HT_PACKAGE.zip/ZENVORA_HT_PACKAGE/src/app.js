/* ZENVORA HT prototype.
   Appwrite credentials are configured in appwrite-config.js.
   Never place an API secret or server key in browser code. */
const $ = (id) => document.getElementById(id);
const appConfig = window.ZENVORA_APPWRITE || {};
let account = null;
let currentUser = null;
let points = 0;

const freeVIP = [
  {name:"VIP 1", fee:"Gratis", tasks:13},
  {name:"VIP 2", fee:"Gratis", tasks:13},
  {name:"VIP 3", fee:"Gratis", tasks:13},
  {name:"VIP 4", fee:"150 GDS", tasks:16},
  {name:"VIP 5", fee:"200 GDS", tasks:19},
  {name:"VIP 6", fee:"250 GDS", tasks:22}
];
const missionBank = [
  ["Kilti jeneral","Ki kapital Ayiti?","Pòtoprens"],
  ["Matematik","Konbyen 8 × 7 fè?","56"],
  ["Konesans dijital","Ki sa yon modpas solid dwe genyen?","lèt"],
  ["Istwa","Ki dat Ayiti pwoklame endepandans li?","1 janvye 1804"],
  ["Syans","Ki planèt nou rete sou li?","latè"],
  ["Lang","Ki lang ofisyèl Ayiti genyen?","kreyòl"]
];
function dayIndex(){const d=new Date();return Math.floor(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/86400000)}
function dailyMissions(){const seed=dayIndex();return Array.from({length:13},(_,i)=>{const q=missionBank[(seed*7+i*3)%missionBank.length];return {id:`${seed}-${i}`,title:q[0],question:q[1],answer:q[2]}})}
function renderMissions(){const host=$("missions");host.innerHTML="";dailyMissions().forEach((m,i)=>{const el=document.createElement("div");el.className="mission";const label=document.createElement("div");label.innerHTML=`<b>${i+1}. ${m.title}</b><div class="muted">${m.question}</div>`;const b=document.createElement("button");b.textContent="Reponn";b.onclick=()=>{const a=prompt(m.question);if(a===null)return;if(a.trim().toLowerCase()===m.answer.toLowerCase()){points+=5;$("points").textContent=points;alert("Bon repons! +5 pwen aprantisaj.");b.disabled=true;b.textContent="Fini";}else alert("Eseye ankò. Li kesyon an byen.");};el.append(label,b);host.append(el)})}
function renderVIP(){const host=$("vipGrid");host.innerHTML="";freeVIP.forEach(v=>{const el=document.createElement("div");el.className="vip";el.innerHTML=`<b>${v.name}</b><strong>${v.fee}</strong><small>${v.tasks} tach/jou</small>`;host.append(el)})}
function switchAuth(login){$("registerForm").classList.toggle("hidden",login);$("loginForm").classList.toggle("hidden",!login);$("authTitle").textContent=login?"Konekte":"Kreye kont";$("authMessage").textContent=""}
$("showLogin").onclick=()=>{switchAuth(true);$("authPanel").scrollIntoView({behavior:"smooth"})};
$("showRegister").onclick=()=>{switchAuth(false);$("authPanel").scrollIntoView({behavior:"smooth"})};
$("registerForm").onsubmit=async(e)=>{e.preventDefault();$("authMessage").textContent="Kont lan pare pou koneksyon Appwrite. Mete Project ID ak Endpoint nan appwrite-config.js anvan enskripsyon aktif."};
$("loginForm").onsubmit=async(e)=>{e.preventDefault();$("authMessage").textContent="Koneksyon Appwrite poko konfigire. Swiv gid ki nan docs/APPWRITE_SETUP.md."};
$("logout").onclick=()=>{$("memberPanel").classList.add("hidden");currentUser=null};
$("copyInvite").onclick=async()=>{const s=$("myInvite").textContent;try{await navigator.clipboard.writeText(s);alert("Kòd la kopye.")}catch{alert(s)}};
renderVIP();renderMissions();
